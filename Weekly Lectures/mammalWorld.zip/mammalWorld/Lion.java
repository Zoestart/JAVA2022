public class Lion extends Mammal {
	
	Lion (int lifeSpanYears, int weightKg){
		this.lifeSpanYears = lifeSpanYears;
		this.weightKg = weightKg;
	}
	public void makeNoise() {
		System.out.println("GRRRRRRRRRR Roar!\n");
	}
}
